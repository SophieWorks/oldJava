import java.util.Scanner;

/**
 * @author Sophie
 * @description tests the box and car classes
 *
 */
public class Tester {
	//constructs car and box
	static Box box = new Box(6, 6, 6);
	static Car car = new Car(0);

	public static void main(String[] args) {

		//calculates box using 
		System.out.println("Volume: " + box.volume());
		System.out.println("SA: " + box.surfaceArea());

		//calculates for car
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("insert start miles:");
		car.startMiles= sc.nextDouble();
		
		System.out.println("insert end miles:");
		car.endMiles= sc.nextDouble();
		
		System.out.println("insert gallons:");
		car.gallons = sc.nextDouble();
		
		System.out.println("MpG is: " + car.calculateMpG());

	}
}
