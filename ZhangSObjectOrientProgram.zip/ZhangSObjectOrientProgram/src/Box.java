/**
 * @author Sophie
 * @description creates a box class with methods and constructor
 *
 */
public class Box {
	private double w; //width
	private double h; //height
	private double l; //length
	
	//start of Box constructor
	public Box(double width, double length, double height) {
		this.w = width;
		this.l = length;
		this.h = height;
	}
	
	public double volume() {
		return (l*w*h);
	}
	
	public double surfaceArea() {
		return(l*w*6);
	}
}

