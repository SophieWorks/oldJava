/**
 * @author Sophie
 * @description creates a car class with methods and constructor
 *
 */
public class Car { 

	double  startMiles;
	double  endMiles; 
	double  gallons;

	//start of Car constructor
	public Car(double begin) {
		this.startMiles = begin ; 
	}
	//end of Car constructor


	//start of calculate MpG method
	public double calculateMpG() { //miles per gallon
		return (endMiles - startMiles)/gallons ; 
	}
	//end of calculate MpG method


	//start of ecoCar method
	public boolean ecoCar() {
		return (calculateMpG() > 30);
	}
	//start of ecoCar method


	//start of gasHog method
	public boolean gasHog() {
		return (calculateMpG() < 15);
	}
	//start of gasHog method


	//start of fillUp method
	public void fillUp(int miles, double gallons ) {
		this.endMiles = miles;
		this.gallons = gallons;
	}
	//end of fill method

}//end of Car class
