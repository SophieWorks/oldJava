/**
 * @author Sophie
 * @date 2018/12/10
 * @version 1.0 2018/12/10
 * @description Enemy class
 */


import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Enemy {

		//variables
		protected int x_pos, y_pos;
		protected Image enemy;

		//constructors
		Enemy(int x, int y){
			x_pos=x;
			y_pos=y;
		}//end enemy

		//Generate Shot
		public EnemyShot genrateShot(){
			EnemyShot EnemyShot1 = new EnemyShot(x_pos+47,y_pos);
			return EnemyShot1;
		}//end EnemyShot
		
		//move the enemy
		public void moveEnemy(int enemySpeed){
			this.y_pos=y_pos+enemySpeed;
		}//end moveEnemy

		//return X
		public int getX(){
			return x_pos;
		}//end getX

		//return Y
		public int getY(){
			return y_pos;
		}//end getY

		//draw enemy
		public void drawEnemy(Graphics g){
			try{
				enemy = ImageIO.read(new File("Enemy.PNG"));
			} catch (IOException e){
				e.printStackTrace();
			}//end try and catch
			g.drawImage(enemy, x_pos, y_pos, null);

	}//end drawEnemy

}//end class