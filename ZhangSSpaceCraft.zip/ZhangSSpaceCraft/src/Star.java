/**
 * @author Sophie
 * @date 2018/12/10
 * @version 1.0 2018/12/10
 * @description Star class
 */

public class Star {

	//variables
	private int x;
	private int y;
	private int size;
	private int speed;
		
	//set size and speed
		
	public Star() {
	   this(0, 0, 1, 1);
	}//end star
		
	//define starts
	public Star(int x, int y, int size, int speed) {	
		this.x = x;
		this.y = y;
		this.size = size;
		this.speed = speed;	
	}//end Star
		
		//return X
		public int getX() {
			return this.x;
		}//end getX
		
		//set X
		public void setX(int x) {
			this.x = x;
		}//end setX
		
		//return y
		public int getY() {	
			return this.y;
		}//end getY
		
		//set y
		public void setY(int y) {	
			this.y = y;
		}//end setY
		
		//return size
		public int getSize() {	
			return this.size;
		}//end getSize
		
		//set size (radius square)
		public void setSize(int radius) {
			this.size = radius;
		}//end setSize
	
		//return speed
		public int getSpeed() {
			return this.speed;
		}//end getSpeed
		
		//set speed
		public void setSpeed(int speed) {
			this.speed = speed;
		}//end setSpeed
		
		//move down	
		public void move() {
			this.y += speed;
		}//end move
		
		//figure out if the star is out of the bottom of the screen
		public boolean isOutside(int width, int height) {	
			if (this.y > height) {
				return true;
			}//end if		
			return false;
		}//end is Outside
		
		//random spawn stars	
		public static Star createRandomWithin(int width, int height) {
			int ranRadius = Main.randomRange(1, 2);
			int ranX = Main.randomRange(0, width-1-(ranRadius*2));
			int ranY = Main.randomRange(0, height-1-(ranRadius*2));
			int ranSpeed = ranRadius;	
			return new Star(ranX, ranY, ranRadius, ranSpeed);
		
		}//end Star
		
}//end class