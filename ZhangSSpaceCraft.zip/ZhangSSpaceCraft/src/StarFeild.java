/**
 * @author Sophie
 * @date 2018/12/10
 * @version 1.0 2018/12/10
 * @description StarFeild class
 */

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class StarFeild {	

	//variables
	private int width;
	private int height;
	private int density;
	private ArrayList<Star> stars;
	
	//start of StarFeild constructor
	public StarFeild(int width, int height, int density) {
		this.width = width;
		this.height = height;
		this.density = density;
		this.stars = new ArrayList<Star>();
		
		//random spawn stars
		for(int i = 0; i < density; i++) {
			this.stars.add(Star.createRandomWithin(width, height));
		}//end for loop density control
	}
	//end of StarFeild constructor
	
	
	//run the StarFeild
	public void doLogic() {
		starCreation();
		StarMovement();
		StarRemoval();
	}//end doLogic
	
	
	//start of starCreation method, creates stars
	public void starCreation() {
		for (int i = stars.size(); i < density; i++) {
			stars.add(Star.createRandomWithin(width, 5));
		}//end for
	}
	//end StarCreation
	
	
	//start of starMovement method
	public void StarMovement() {
		for (Star star : stars) {
			star.move();
		}//end for 
	}
	//end StarMovement
	
	
	//start of starRemoval method, removes stars
	public void StarRemoval() {
		for (Star star : stars) {
			if (star.isOutside(width, height)) {
				stars.remove(star);
				StarRemoval();
				return;
			}//end if
		}//end for
	}
	//end of StarRemoval
	
	
	//draw star
	public void draw(Graphics g) {
		for (Star star : stars) {			
			g.setColor(Color.WHITE);
			g.fillOval(star.getX(), star.getY(), star.getSize(), star.getSize());
		}//end for 
	}//end draw
	
}//end class