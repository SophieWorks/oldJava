/**
 * @author Sophie
 * @date 2018/12/10
 * @version 1.0 2018/12/10
 * @description asteroid class
 */

import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Asteroid {
	//variables
	protected int x_pos, y_pos;
	protected Image asteroid;

	//start of Asteroid constructor
	Asteroid(int x, int y){
		x_pos=x;
		y_pos=y;
	}//end Asteroid


	//start of moveAsteroid method
	public void moveAsteroid(int enemySpeed){
		this.y_pos=y_pos+enemySpeed;
	}
	//end moveAsteroid


	//start of getX
	public int getX(){
		return x_pos;
	}
	//end of getX

	//return Y
	public int getY(){
		return y_pos;
	}
	//end of getY
	

	//start of drawAsteroid
	public void drawAsteroid(Graphics g){
		try{
			asteroid = ImageIO.read(new File("Asteroid.png"));
		} catch (IOException e){
			e.printStackTrace();
		}//end try and catch	
		g.drawImage(asteroid, x_pos, y_pos, null);

	}
	//end of drawAsteroid

}//end class