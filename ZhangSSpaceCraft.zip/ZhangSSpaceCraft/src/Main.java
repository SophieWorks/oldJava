/**
 * @author Sophie
 * @date 2018/12/10
 * @version 1.0 2018/12/10
 * @description Main class
 */

import java.awt.*;
import java.applet.*;

//public class Main extends JApplet
public class Main extends Applet implements Runnable{

	// variables
	static Thread th;
	private SpaceCraft spacecraft;
	private Asteroid[] asteroid;
	private Enemy [] enemy;
	private Shot [] shots;
	private EnemyShot [] enemyShot;
	private Rectangle[] rectAsteroid;
	private Rectangle[] rectEnemy;
	private Rectangle[] rectShots;
	private Rectangle[] rectEnemyShots;
	private Rectangle rectPlayer;
	private StarFeild starFeild;


	//speeds
	private final int shotSpeed = -4;
	private final int playerLeftSpeed = -3;
	private final int playerRightSpeed = 3;
	private final int playerUpSpeed = -3;
	private final int playerDownSpeed = 3;
	private int enemySpeed = 1;
	private int enemySpeedUp = 0;


	//directions
	boolean playerMoveLeft;
	boolean playerMoveRight;
	boolean playerMoveUp;
	boolean playerMoveDown;


	//buffering
	private Image dbImage;
	private Graphics dbg;


	// Labels
	String strLifes = "Lives: ";
	String strScore = "Score: ";
	int Score;
	int Lifes;


	//enemy spawn timers
	int EnemySpawn;
	int AsteroidSpawn;


	//initialize the window
	public void init()  {
		//sets window
		setSize (1380, 900);
		setBackground (Color.black);

		//spaceCraft locations
		spacecraft = new SpaceCraft(600, 700);		
		rectPlayer = new Rectangle(spacecraft.getX(), spacecraft.getY(), 120 , 111);

		//Asteroid
		asteroid = new Asteroid[5]; 													
		rectAsteroid = new Rectangle[5];

		//Enemy
		enemy = new Enemy[5]; 													
		rectEnemy = new Rectangle[5];

		//Shots
		shots = new Shot[30];  													
		rectShots = new Rectangle[30];

		//EnemyShots
		enemyShot = new EnemyShot[30];  													
		rectEnemyShots = new Rectangle[30];

		// Sets StarFeild size
		starFeild = new StarFeild(this.getWidth(), this.getHeight(), 50);

		//keeps track of score and lives
		Score=0;
		Lifes=3;
	}
	//end initialization of the window


	//starts the applet
	public void start ()  {
		th = new Thread(this);
		th.start ();
	}//end start


	//start of randomRange method
	public static int randomRange (int min, int max){
		int range = (max - min) + 1;     
		return (int)(Math.random() * range) + min;
	}//end randomWithRange

	// run the  whole program (main body)
	public void run ()  {
		Thread.currentThread().setPriority(Thread.MIN_PRIORITY);

		while (true)  {
			EnemySpawn = (int) (Math.random()*750);
			//spawn enemy from the top of the screen
			for (int i=0;i<enemy.length;i++){
				if (EnemySpawn>30 && EnemySpawn<35) {
					if (enemy[i] == null) {
						enemy[i] = new Enemy((int)(Math.random()* 1290),0);
						rectEnemy[i] = new Rectangle(enemy[i].getX(), enemy[i].getY(), 89 , 100);

						//spawn shots when enemy spawned
						for (i=0; i < enemyShot.length; i++){
							if (enemyShot[i] == null){
								enemyShot[i] = enemy[i].genrateShot();
								rectEnemyShots[i] = new Rectangle(enemyShot[i].getX(), enemyShot[i].getY(), 10 , 10);
								break;
							}//end if 
						}//end for loop 

						break;
					}//end if 
				}//end if 
			}//end for 			

			//asteroid starts from top of screen
			for (int i = 0; i < asteroid.length; i++){
				AsteroidSpawn = (int) (Math.random() * 775);
				if (asteroid[i] == null) {
					if (AsteroidSpawn > 30 && AsteroidSpawn < 35) {
						asteroid[i] = new Asteroid((int)(Math.random() * 1290) , 0);
						rectAsteroid[i] = new Rectangle(asteroid[i].getX(), asteroid[i].getY(), 89 , 100);
						break;
					}//end if 
				}//end if 
			}//end for 

			starFeild.doLogic();

			//Shots of player
			for (int i = 0; i < shots.length; i++){
				if (shots[i] != null)  {
					shots[i].moveShot(shotSpeed);//move shot		
					rectShots[i].setLocation(shots[i].x_pos, shots[i].y_pos);
					//set the shot to null when out of the frame
					if (shots[i].getY() < 0) {
						shots[i] = null;
					}//end if 
				}//end if 
			}//end for 

			// EnemyShots
			for (int i = 0; i < enemyShot.length; i++){
				if (enemyShot[i] != null) {
					enemyShot[i].moveShot(shotSpeed);//move shot
					rectEnemyShots[i].setLocation(enemyShot[i].x_pos, enemyShot[i].y_pos);
					//set the shot to null when out of the frame
					if (enemyShot[i].getY() > 1380) {
						enemyShot[i] = null;
					}//end if 
				}//end if
			}//end for

			// Enemy
			for (int i = 0; i < enemy.length; i++){
				if (enemy[i] != null){
					enemy[i].moveEnemy(enemySpeed);		//move enemies
					rectEnemy[i].setLocation(enemy[i].x_pos, enemy[i].y_pos);

					//reset the enemy when it is out of the frame
					if (enemy[i].getY() > this.getHeight()){
						enemy[i] = new Enemy((int)(Math.random()*(this.getWidth()- 89)),0);

						//if enemy went outside the screen and without getting shot, respawn enemy with shots
						for (i = 0; i < enemyShot.length; i++){
							if (enemyShot[i] == null){
								//System.out.println("shoot");
								enemyShot[i] = enemy[i].genrateShot();
								rectEnemyShots[i] = new Rectangle(enemyShot[i].getX(), enemyShot[i].getY(), 10 , 10);
								break;
							}//end if 
						}//end for 

					}//end if
				}//end if 
			}//end for

			// Asteroid
			for (int i = 0; i < asteroid.length; i++){
				if (asteroid[i] != null){
					asteroid[i].moveAsteroid(enemySpeed + enemySpeedUp);//move enemies
					rectAsteroid[i].setLocation(asteroid[i].x_pos, asteroid[i].y_pos);

					//reset the enemy when it is out of the frame
					if (asteroid[i].getY() > this.getHeight()){
						asteroid[i] = new Asteroid((int)(Math.random()*(this.getWidth()- 80)),0);
					}//end if 
				}//end if 
			}//end for

			//tests for collision of shots and enemies
			for (int i = 0; i < shots.length; i++){
				if(shots[i] != null){
					for(int a = 0; a < enemy.length; a++){
						if (enemy[a] != null){
							if (rectShots[i].intersects(rectEnemy[a])){//collides
								//System.out.println("hit");
								Score = Score+100;				//score +
								shots[i] = null;					//remove shots
								enemy[a] = new Enemy ((int)(Math.random()*(this.getWidth()- 89)), -100);//set enemy to null and respawn without shots
								enemySpeedUp = Score / 1000;		//control the speed of asteroids
								break;
							}//end if 
						}//end if 
					}//end for 
				}//end if 
			}//end for

			//tests for collision of shots and asteroids
			for (int i = 0; i < shots.length; i++){
				if(shots[i] != null){
					for (int a = 0; a < asteroid.length; a++){
						if (asteroid[a] != null){
							if (rectShots[i].intersects(rectAsteroid[a])){//collides
								shots[i] = null;					//remove shots
								break;
							}//end if 
						}//end if 
					}//end for 
				}//end if 
			}//end for

			//tests for collision of enemies and player
			for (int i = 0; i < enemy.length; i++){
				if (enemy[i] != null){
					if (rectPlayer.intersects(rectEnemy[i])){
						enemy[i] = null;			//set enemy to null and respawn without shots
						Lifes = Lifes - 1;
						if (Lifes == 0){			//if player got hit 3 times
							Score = 0;			//reset score
							Lifes = 3;			//reset lives
							enemySpeedUp = 0;	//reset enemy speed
						}//end if 
					}//end if 
				}//end if 
			}//end for 

			//tests for collision of enemyshots and player
			for (int i = 0; i < enemyShot.length; i++){
				if (enemyShot[i] != null){
					if (rectPlayer.intersects(rectEnemyShots[i])){
						enemyShot[i] = null;
						Lifes = Lifes - 1;
						if (Lifes == 0){			//if player got hit 3 times
							Score = 0;			//reset score
							Lifes = 3;			//reset lives
							enemySpeedUp = 0;	//reset enemy speed
						}//end if
					}//end if
				}//end if 
			}//end for 

			//tests for collision of asteroids and player
			for (int i = 0; i < asteroid.length; i++){
				if (asteroid[i] != null){
					if (rectPlayer.intersects(rectAsteroid[i])){
						asteroid[i] = null;
						Lifes = Lifes - 1;
						if (Lifes == 0){			//if player got hit 3 times
							Score = 0;			//reset score
							Lifes = 3;			//reset lives
							enemySpeedUp = 0;	//reset enemy speed
						}//end if 
					}//end if
				}//end if 
			}//end for 

			//player controls
			if (playerMoveLeft && spacecraft.getX() > 10)   {
				spacecraft.moveX(playerLeftSpeed);
				rectPlayer.setLocation(spacecraft.x_pos, spacecraft.y_pos);
			}//end if

			if (playerMoveRight && spacecraft.getX() + 10 < this.getWidth())   {
				spacecraft.moveX(playerRightSpeed);
				rectPlayer.setLocation(spacecraft.x_pos, spacecraft.y_pos);
			}//end if

			if (playerMoveUp && spacecraft.getY() > 0)   {
				spacecraft.moveY(playerUpSpeed);
				rectPlayer.setLocation(spacecraft.x_pos, spacecraft.y_pos);
			}//end if

			if (playerMoveDown && spacecraft.getY() + 111 < this.getHeight())   {
				spacecraft.moveY(playerDownSpeed);
				rectPlayer.setLocation(spacecraft.x_pos, spacecraft.y_pos);
			}//end if

			repaint();

			//refresh
			try {
				Thread.sleep(10);
			}catch (InterruptedException ex){
			}//end try and catch

			Thread.currentThread().setPriority(Thread.MIN_PRIORITY);

		}//end while
	}//end run

	//Key controls press
	public boolean keyDown(Event e, int key){
		int i = 0;
		if (key == Event.LEFT) {
			playerMoveLeft = true;
		}//end if

		if (key == Event.RIGHT){
			playerMoveRight = true;
		}//end if

		if (key == Event.UP){
			playerMoveUp = true;
		}//end if

		if (key == Event.DOWN){
			playerMoveDown = true;
		}//end if

		if (key == 32){
			// generate new shot and add it to shots array
			for(i = 0; i < shots.length; i++){
				if (shots[i] == null){
					shots[i] = spacecraft.genrateShot();
					rectShots[i] = new Rectangle(shots[i].getX(), shots[i].getY(), 10 , 10);
					break;
				}//end if
			}//end for
		}//end if

		return true;
	}//end keyDown

	//Key controls release
	public boolean keyUp(Event e, int key)  {
		if (key == Event.LEFT){
			playerMoveLeft = false;
		}//end if

		if (key == Event.RIGHT){
			playerMoveRight = false;
		}//end if

		if (key == Event.UP){
			playerMoveUp = false;
		}//end if

		if (key == Event.DOWN){
			playerMoveDown = false;
		}//end if
		return true;
	}//end keyUp

	//update the image
	public void update (Graphics g)  {
		if (dbImage == null)    {
			dbImage = createImage (this.getSize().width, this.getSize().height);
			dbg = dbImage.getGraphics ();
		}//end if

		dbg.setColor (getBackground ());
		dbg.fillRect (0, 0, this.getSize().width, this.getSize().height);

		dbg.setColor (getForeground());
		paint (dbg);

		g.drawImage (dbImage, 0, 0, this);
	}//end update

	//draw image
	public void paint (Graphics g){
		// draw player
		starFeild.draw(g);
		spacecraft.drawPlayer(g);
		// draw shots
		for(int i=0; i<shots.length; i++){
			if(shots[i] != null){
				shots[i].drawShot(g);
			}//end if
		}//end for

		// draw Enemy Shots
		for(int i=0; i<enemyShot.length; i++){
			if(enemyShot[i] != null){
				enemyShot[i].drawShot(g);
			}//end if
		}//end for

		// draw Enemies
		for (int i=0; i<enemy.length; i++){
			if (enemy[i]!=null){
				enemy[i].drawEnemy(g);
				//print
			}//end if
		}//end for

		// draw Asteroids
		for (int i=0; i<asteroid.length; i++){
			if (asteroid[i]!=null){
				asteroid[i].drawAsteroid(g);
				//print
			}//end if
		}////end for 

		// draw stars
		g.setColor(Color.white);
		g.setFont(new Font(g.getFont().toString(),0,20));
		g.drawString(strLifes+Lifes, 20, 40);
		g.drawString(strScore+Score, this.getWidth()-200, 40);
	}//end paint

	public String getAppletInfo() {
		// provide information about the applet
		return "Title:   \nAuthor:   \nA simple applet example description. ";
	}//end getAppletInfo

	public String[][] getParameterInfo() {
		// provide parameter information about the applet
		String paramInfo[][] = {
				{"firstParameter",    "1-10",    "description of first parameter"},
				{"status", "boolean", "description of second parameter"},
				{"images",   "url",     "description of third parameter"}
		};
		return paramInfo;
	}//end getParameterInfo
}//end main