/**
 * @author Sophie
 * @date 2018/12/10
 * @version 1.0 2018/12/10
 * @description SpaceCraft class
 */

import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class SpaceCraft {

	//variables
		protected int x_pos;
		protected int y_pos;
		protected Image spaceCraft;

		//SpaceCraft constructor
		SpaceCraft(int x, int y) {
			this.x_pos = x;
			this.y_pos = y;
		}//end of Spacecraft

		//Generate Shot
		public Shot genrateShot(){
			Shot Shot1 = new Shot(x_pos + 50,y_pos);
			return Shot1;
		}//end shot

		//MoveX
		public void moveX(int distance) {
			x_pos=x_pos + distance;
		}//end moveX

		//MoveY
		public void moveY(int distance) {
			y_pos=y_pos + distance;
		}//end moveY

		//getX 
		public int getX(){
			return x_pos;
		}//end getX

		//getY
		public int getY(){
			return y_pos;
		}//end getY

		//draw player
		public void drawPlayer(Graphics g) {
			try {
				spaceCraft = ImageIO.read(new File("Player.png"));
			}catch (IOException e) {
				e.printStackTrace();
			}//end try and catch 
			g.drawImage(spaceCraft, x_pos, y_pos, null);  
		}//end drawPlayer
		
	}//end class